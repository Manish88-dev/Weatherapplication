

### Snapshot

* Default 
<img src="ss/demo1.png" width="100%">

* when you entered any valid city
 <img src="ss/demo.png" width="100%">

* when you did'nt entered anything 
 <img src="ss/empty.png" width="100%">

* when entered city did'nt matched with data
 <img src="ss/bad.png" width="100%">



